import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'routerApp';

  constructor(private rter:Router){

  }

  navigatePage(){
     this.rter.navigate(['/first']);
  }


  navigateBookPage(id:string){
       this.rter.navigate(['/book',id])
  }
}
