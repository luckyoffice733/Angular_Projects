import { Component,OnInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.css'],

})
export class SecondComponent implements OnInit{

  username:string|null='';
  constructor(private atrute:ActivatedRoute){}


ngOnInit(): void {
    this.atrute.queryParams.subscribe(params =>{
     console.log("query params from second : " ,params['uname']);
     this.username=params['uname'];
    })
}

}
