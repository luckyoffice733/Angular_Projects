import { Component } from '@angular/core';

@Component({
  selector: 'app-contatus',
  templateUrl: './contatus.component.html',
  styleUrls: ['./contatus.component.css']
})
export class ContatusComponent {

}
