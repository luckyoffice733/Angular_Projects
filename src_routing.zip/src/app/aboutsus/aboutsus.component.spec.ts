import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutsusComponent } from './aboutsus.component';

describe('AboutsusComponent', () => {
  let component: AboutsusComponent;
  let fixture: ComponentFixture<AboutsusComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AboutsusComponent]
    });
    fixture = TestBed.createComponent(AboutsusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
