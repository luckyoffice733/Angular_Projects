import { Component } from '@angular/core';

@Component({
  selector: 'app-aboutsus',
  templateUrl: './aboutsus.component.html',
  styleUrls: ['./aboutsus.component.css']
})
export class AboutsusComponent {

}
