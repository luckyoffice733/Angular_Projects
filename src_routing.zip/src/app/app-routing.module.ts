import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FirstComponent } from './first/first.component';
import { SecondComponent } from './second/second.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { BookComponent } from './book/book.component';
import { Title } from '@angular/platform-browser';
import { AboutsusComponent } from './aboutsus/aboutsus.component';
import { HomeComponent } from './home/home.component';
import { ContatusComponent } from './contatus/contatus.component';

const routes: Routes = [
  {path:'first',title:'First',component:FirstComponent},
  {path:'second',title:'Second',component:SecondComponent},
  {path:'',title:'Login',redirectTo:'/second',pathMatch:'full'},
  {path:'book/:id',title:'Book',component:BookComponent},
  {path:'aboutus',component:AboutsusComponent,
    children:[
      {path:'home',component:HomeComponent},
      {path:'contact',component:ContatusComponent}
    ]
  },

   {path:'**',component:PagenotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
