import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FirstComponent } from './first/first.component';
import { SecondComponent } from './second/second.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { BookComponent } from './book/book.component';
import { FormsModule } from '@angular/forms';
import { AboutsusComponent } from './aboutsus/aboutsus.component';
import { HomeComponent } from './home/home.component';
import { ContatusComponent } from './contatus/contatus.component';

@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    SecondComponent,
    PagenotfoundComponent,
    BookComponent,
    AboutsusComponent,
    HomeComponent,
    ContatusComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
