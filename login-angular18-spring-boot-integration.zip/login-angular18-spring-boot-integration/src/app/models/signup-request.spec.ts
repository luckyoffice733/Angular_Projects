import { SignupRequest } from './signup-request';

describe('SignupRequest', () => {
  it('should create an instance', () => {
    expect(new SignupRequest()).toBeTruthy();
  });
});
