import { SignupResponse } from './signup-response';

describe('SignupResponse', () => {
  it('should create an instance', () => {
    expect(new SignupResponse()).toBeTruthy();
  });
});
