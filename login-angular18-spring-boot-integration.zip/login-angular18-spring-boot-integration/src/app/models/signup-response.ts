export class SignupResponse {
    response?: string
}
