import { Component } from '@angular/core';
import { EmployeeServiceService } from './employee-service.service';
import { Employee } from './employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'exampleOnService';

   fromTheSerivce:Employee[]=[];

  constructor(private empService:EmployeeServiceService){
          this.fromTheSerivce= this.empService.getEmployeDetails();
  }



}
