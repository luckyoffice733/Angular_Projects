export class Employee {
      empid:number;
      empName:string;
      sal:number
      constructor(empid:number,empName:string,sal:number){
            this.empid=empid;
            this.empName=empName;
            this.sal=sal;
      }
}
