import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {

  constructor() { }

  empData:Employee[]=[
    {"empid":12121,"empName":'smith',"sal":6000},
    {"empid":10311,"empName":'Allen',"sal":14000},
    {"empid":2001,"empName":'John',"sal":5000},
  ]


  getEmployeDetails(){
     return this.empData;
  }





}
